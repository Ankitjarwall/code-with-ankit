package barcodescanner.xservices.nl.barcodescanner;

public final class R
{
  public static final class array
  {
    public static final int country_codes = 2130771968;
    public static final int preferences_front_light_options = 2130771969;
    public static final int preferences_front_light_values = 2130771970;
  }
  
  public static final class bool
  {
    public static final int abc_action_bar_embed_tabs = 2130903040;
  }
  
  public static final class color
  {
    public static final int contents_text = 2130968591;
    public static final int encode_view = 2130968592;
    public static final int possible_result_points = 2130968597;
    public static final int primary_text_default_material_dark = 2130968598;
    public static final int result_minor_text = 2130968599;
    public static final int result_points = 2130968600;
    public static final int result_text = 2130968601;
    public static final int result_view = 2130968602;
    public static final int ripple_material_light = 2130968603;
    public static final int secondary_text_default_material_dark = 2130968604;
    public static final int secondary_text_default_material_light = 2130968605;
    public static final int status_text = 2130968606;
    public static final int transparent = 2130968608;
    public static final int viewfinder_laser = 2130968609;
    public static final int viewfinder_mask = 2130968610;
  }
  
  public static final class dimen
  {
    public static final int half_padding = 2131034119;
    public static final int notification_large_icon_height = 2131034124;
    public static final int notification_large_icon_width = 2131034125;
    public static final int notification_subtext_size = 2131034132;
    public static final int standard_padding = 2131034135;
  }
  
  public static final class drawable
  {
    public static final int flip_camera = 2131099668;
    public static final int launcher_icon = 2131099678;
    public static final int notification_template_icon_bg = 2131099687;
    public static final int share_via_barcode = 2131099693;
    public static final int toggle_torch = 2131099694;
  }
  
  public static final class id
  {
    public static final int action0 = 2131165184;
    public static final int action_divider = 2131165186;
    public static final int app_picker_list_item_icon = 2131165193;
    public static final int app_picker_list_item_label = 2131165194;
    public static final int barcode_image_view = 2131165197;
    public static final int bookmark_title = 2131165199;
    public static final int bookmark_url = 2131165200;
    public static final int buttonPanel = 2131165207;
    public static final int cancel_action = 2131165208;
    public static final int chronometer = 2131165213;
    public static final int contents_supplement_text_view = 2131165217;
    public static final int contents_text_view = 2131165218;
    public static final int decode = 2131165220;
    public static final int decode_failed = 2131165221;
    public static final int decode_succeeded = 2131165222;
    public static final int end = 2131165223;
    public static final int end_padder = 2131165224;
    public static final int flip_button = 2131165232;
    public static final int format_text_view = 2131165234;
    public static final int help_contents = 2131165236;
    public static final int history_detail = 2131165237;
    public static final int history_title = 2131165238;
    public static final int icon = 2131165239;
    public static final int image_view = 2131165242;
    public static final int info = 2131165243;
    public static final int launch_product_query = 2131165245;
    public static final int line1 = 2131165248;
    public static final int line3 = 2131165249;
    public static final int media_actions = 2131165251;
    public static final int menu_encode = 2131165252;
    public static final int menu_help = 2131165253;
    public static final int menu_history = 2131165254;
    public static final int menu_history_clear_text = 2131165255;
    public static final int menu_history_send = 2131165256;
    public static final int menu_settings = 2131165257;
    public static final int menu_share = 2131165258;
    public static final int meta_text_view = 2131165259;
    public static final int meta_text_view_label = 2131165260;
    public static final int none = 2131165261;
    public static final int normal = 2131165262;
    public static final int page_number_view = 2131165271;
    public static final int preview_view = 2131165273;
    public static final int query_button = 2131165274;
    public static final int query_text_view = 2131165275;
    public static final int quit = 2131165276;
    public static final int restart_preview = 2131165277;
    public static final int result_button_view = 2131165278;
    public static final int result_list_view = 2131165279;
    public static final int result_view = 2131165280;
    public static final int return_scan_result = 2131165281;
    public static final int share_app_button = 2131165287;
    public static final int share_bookmark_button = 2131165288;
    public static final int share_clipboard_button = 2131165289;
    public static final int share_contact_button = 2131165290;
    public static final int share_text_view = 2131165291;
    public static final int snippet_view = 2131165292;
    public static final int status_bar_latest_event_content = 2131165296;
    public static final int status_view = 2131165297;
    public static final int text = 2131165299;
    public static final int text2 = 2131165300;
    public static final int time = 2131165301;
    public static final int time_text_view = 2131165302;
    public static final int title = 2131165303;
    public static final int torch_button = 2131165306;
    public static final int type_text_view = 2131165307;
    public static final int viewfinder_view = 2131165308;
  }
  
  public static final class integer
  {
    public static final int cancel_button_image_alpha = 2131230720;
    public static final int status_bar_notification_info_maxnum = 2131230722;
  }
  
  public static final class layout
  {
    public static final int app_picker_list_item = 2131296257;
    public static final int bookmark_picker_list_item = 2131296258;
    public static final int capture = 2131296261;
    public static final int encode = 2131296262;
    public static final int help = 2131296265;
    public static final int history_list_item = 2131296266;
    public static final int notification_media_action = 2131296269;
    public static final int notification_media_cancel_action = 2131296270;
    public static final int notification_template_big_media = 2131296271;
    public static final int notification_template_big_media_narrow = 2131296273;
    public static final int notification_template_media = 2131296278;
    public static final int notification_template_part_chronometer = 2131296280;
    public static final int notification_template_part_time = 2131296281;
    public static final int search_book_contents = 2131296283;
    public static final int search_book_contents_header = 2131296284;
    public static final int search_book_contents_list_item = 2131296285;
    public static final int share = 2131296286;
  }
  
  public static final class menu
  {
    public static final int capture = 2131361792;
    public static final int encode = 2131361793;
    public static final int history = 2131361794;
  }
  
  public static final class raw
  {
    public static final int beep = 2131492864;
  }
  
  public static final class string
  {
    public static final int app_name = 2131558401;
    public static final int app_picker_name = 2131558402;
    public static final int bookmark_picker_name = 2131558403;
    public static final int button_add_calendar = 2131558404;
    public static final int button_add_contact = 2131558405;
    public static final int button_book_search = 2131558406;
    public static final int button_cancel = 2131558407;
    public static final int button_custom_product_search = 2131558408;
    public static final int button_dial = 2131558409;
    public static final int button_email = 2131558410;
    public static final int button_get_directions = 2131558411;
    public static final int button_mms = 2131558412;
    public static final int button_ok = 2131558413;
    public static final int button_open_browser = 2131558414;
    public static final int button_product_search = 2131558415;
    public static final int button_search_book_contents = 2131558416;
    public static final int button_share_app = 2131558417;
    public static final int button_share_bookmark = 2131558418;
    public static final int button_share_by_email = 2131558419;
    public static final int button_share_by_sms = 2131558420;
    public static final int button_share_clipboard = 2131558421;
    public static final int button_share_contact = 2131558422;
    public static final int button_show_map = 2131558423;
    public static final int button_sms = 2131558424;
    public static final int button_web_search = 2131558425;
    public static final int button_wifi = 2131558426;
    public static final int contents_contact = 2131558444;
    public static final int contents_email = 2131558445;
    public static final int contents_location = 2131558446;
    public static final int contents_phone = 2131558447;
    public static final int contents_sms = 2131558448;
    public static final int contents_text = 2131558449;
    public static final int history_clear_one_history_text = 2131558466;
    public static final int history_clear_text = 2131558467;
    public static final int history_email_title = 2131558468;
    public static final int history_empty = 2131558469;
    public static final int history_empty_detail = 2131558470;
    public static final int history_send = 2131558471;
    public static final int history_title = 2131558472;
    public static final int menu_encode_mecard = 2131558474;
    public static final int menu_encode_vcard = 2131558475;
    public static final int menu_help = 2131558476;
    public static final int menu_history = 2131558477;
    public static final int menu_settings = 2131558478;
    public static final int menu_share = 2131558479;
    public static final int msg_bulk_mode_scanned = 2131558480;
    public static final int msg_camera_framework_bug = 2131558481;
    public static final int msg_default_format = 2131558482;
    public static final int msg_default_meta = 2131558483;
    public static final int msg_default_mms_subject = 2131558484;
    public static final int msg_default_status = 2131558485;
    public static final int msg_default_time = 2131558486;
    public static final int msg_default_type = 2131558487;
    public static final int msg_encode_contents_failed = 2131558488;
    public static final int msg_error = 2131558489;
    public static final int msg_google_books = 2131558490;
    public static final int msg_google_product = 2131558491;
    public static final int msg_intent_failed = 2131558492;
    public static final int msg_invalid_value = 2131558493;
    public static final int msg_redirect = 2131558494;
    public static final int msg_sbc_book_not_searchable = 2131558495;
    public static final int msg_sbc_failed = 2131558496;
    public static final int msg_sbc_no_page_returned = 2131558497;
    public static final int msg_sbc_page = 2131558498;
    public static final int msg_sbc_results = 2131558499;
    public static final int msg_sbc_searching_book = 2131558500;
    public static final int msg_sbc_snippet_unavailable = 2131558501;
    public static final int msg_share_explanation = 2131558502;
    public static final int msg_share_text = 2131558503;
    public static final int msg_sure = 2131558504;
    public static final int msg_unmount_usb = 2131558505;
    public static final int preferences_actions_title = 2131558507;
    public static final int preferences_auto_focus_title = 2131558508;
    public static final int preferences_auto_open_web_title = 2131558509;
    public static final int preferences_bulk_mode_summary = 2131558510;
    public static final int preferences_bulk_mode_title = 2131558511;
    public static final int preferences_copy_to_clipboard_title = 2131558512;
    public static final int preferences_custom_product_search_summary = 2131558513;
    public static final int preferences_custom_product_search_title = 2131558514;
    public static final int preferences_decode_1D_industrial_title = 2131558515;
    public static final int preferences_decode_1D_product_title = 2131558516;
    public static final int preferences_decode_Aztec_title = 2131558517;
    public static final int preferences_decode_Data_Matrix_title = 2131558518;
    public static final int preferences_decode_PDF417_title = 2131558519;
    public static final int preferences_decode_QR_title = 2131558520;
    public static final int preferences_device_bug_workarounds_title = 2131558521;
    public static final int preferences_disable_barcode_scene_mode_title = 2131558522;
    public static final int preferences_disable_continuous_focus_summary = 2131558523;
    public static final int preferences_disable_continuous_focus_title = 2131558524;
    public static final int preferences_disable_exposure_title = 2131558525;
    public static final int preferences_disable_metering_title = 2131558526;
    public static final int preferences_front_light_auto = 2131558527;
    public static final int preferences_front_light_off = 2131558528;
    public static final int preferences_front_light_on = 2131558529;
    public static final int preferences_front_light_summary = 2131558530;
    public static final int preferences_front_light_title = 2131558531;
    public static final int preferences_general_title = 2131558532;
    public static final int preferences_history_summary = 2131558533;
    public static final int preferences_history_title = 2131558534;
    public static final int preferences_invert_scan_summary = 2131558535;
    public static final int preferences_invert_scan_title = 2131558536;
    public static final int preferences_name = 2131558537;
    public static final int preferences_orientation_title = 2131558538;
    public static final int preferences_play_beep_title = 2131558539;
    public static final int preferences_remember_duplicates_summary = 2131558540;
    public static final int preferences_remember_duplicates_title = 2131558541;
    public static final int preferences_result_title = 2131558542;
    public static final int preferences_scanning_title = 2131558543;
    public static final int preferences_search_country = 2131558544;
    public static final int preferences_supplemental_summary = 2131558545;
    public static final int preferences_supplemental_title = 2131558546;
    public static final int preferences_vibrate_title = 2131558547;
    public static final int result_address_book = 2131558549;
    public static final int result_calendar = 2131558550;
    public static final int result_email_address = 2131558551;
    public static final int result_geo = 2131558552;
    public static final int result_isbn = 2131558553;
    public static final int result_product = 2131558554;
    public static final int result_sms = 2131558555;
    public static final int result_tel = 2131558556;
    public static final int result_text = 2131558557;
    public static final int result_uri = 2131558558;
    public static final int result_wifi = 2131558559;
    public static final int sbc_name = 2131558560;
    public static final int status_bar_notification_info_overflow = 2131558562;
    public static final int wifi_changing_network = 2131558563;
  }
  
  public static final class style
  {
    public static final int CaptureTheme = 2131623936;
    public static final int ResultButton = 2131623937;
    public static final int ShareButton = 2131623938;
  }
  
  public static final class xml
  {
    public static final int preferences = 2131755011;
  }
}


/* Location:              C:\Users\ankit\Documents\GitHub\code-with-ankit\Andriod\Decompilation\dex2jar-2.0\classes-dex2jar.jar!\barcodescanner\xservices\nl\barcodescanner\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */