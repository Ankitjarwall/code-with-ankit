package com.google.android.gms.common.api;

import android.support.annotation.NonNull;

public class zze<T extends Result>
{
  private T zzazt;
  
  public void zzb(@NonNull T paramT)
  {
    this.zzazt = paramT;
  }
  
  @NonNull
  protected T zzvs()
  {
    return this.zzazt;
  }
}


/* Location:              C:\Users\ankit\Documents\GitHub\code-with-ankit\Andriod\Decompilation\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\common\api\zze.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */