package com.google.android.gms.auth.api.signin.internal;

public class zzh
{
  static int zzakE = 31;
  private int zzakF = 1;
  
  public zzh zzad(boolean paramBoolean)
  {
    int j = zzakE;
    int k = this.zzakF;
    if (paramBoolean) {}
    for (int i = 1;; i = 0)
    {
      this.zzakF = (i + k * j);
      return this;
    }
  }
  
  public zzh zzq(Object paramObject)
  {
    int j = zzakE;
    int k = this.zzakF;
    if (paramObject == null) {}
    for (int i = 0;; i = paramObject.hashCode())
    {
      this.zzakF = (i + k * j);
      return this;
    }
  }
  
  public int zzru()
  {
    return this.zzakF;
  }
}


/* Location:              C:\Users\ankit\Documents\GitHub\code-with-ankit\Andriod\Decompilation\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\auth\api\signin\internal\zzh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */