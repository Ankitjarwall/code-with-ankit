package com.google.android.gms.common.internal.safeparcel;

public abstract class zza
  implements SafeParcelable
{
  public final int describeContents()
  {
    return 0;
  }
}


/* Location:              C:\Users\ankit\Documents\GitHub\code-with-ankit\Andriod\Decompilation\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\common\internal\safeparcel\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */