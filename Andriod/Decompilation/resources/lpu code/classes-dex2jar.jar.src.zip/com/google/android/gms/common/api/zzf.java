package com.google.android.gms.common.api;

import java.util.Map;
import java.util.WeakHashMap;

public abstract class zzf
{
  private static final Map<Object, zzf> zzazv = new WeakHashMap();
  private static final Object zztX = new Object();
  
  public abstract void remove(int paramInt);
}


/* Location:              C:\Users\ankit\Documents\GitHub\code-with-ankit\Andriod\Decompilation\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\common\api\zzf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */