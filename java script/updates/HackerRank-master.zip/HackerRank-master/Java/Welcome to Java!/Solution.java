Welcome to the world of Java! In this challenge, we practice printing to stdout.

The code stubs in your editor declare a Solution class and a main method.


//Output Format

//You must print two lines of output:

//Print Hello, World. on the first line.
//Print Hello, Java. on the second line.

//Sample Output

//Hello, World.
//Hello, Java.

public class Solution {

    public static void main(String[] args) {
        /* Enter your code here. Print output to STDOUT. Your class should be named Solution. */
        System.out.println("Hello, World.");
        System.out.println("Hello, Java.");
    }
}