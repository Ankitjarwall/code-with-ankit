import React from 'react'
import Navbar from './navbar'

function Onefood(){
     
        return (
            <div>
                <Navbar/>
                <h1>get food info by id</h1>
            </div>
        )
    }


export default Onefood
