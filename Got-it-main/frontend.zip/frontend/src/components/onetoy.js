import React from 'react'
import Navbar from './navbar'

function Onetoy(){
     
        return (
            <div>
                <Navbar />
                <h1>get toy
                 info by id</h1>
            </div>
        )
    }


export default Onetoy
