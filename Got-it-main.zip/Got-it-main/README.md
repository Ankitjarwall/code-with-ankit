got-it

Web Site live - https://46f1-149-129-133-212.ap.ngrok.io/<br />
Hosting server - alibabacloud.com (Windows Server 2012 R2 Datacenter 64-bit )<br />
Type - Shared Performance Basic

Project Team<br />
Ankit Meena<br />
Ayush Singh<br />
Amartya Singh<br />

Email - ankitjarwalll@gmail.com<br />
contact - 9549112724<br />
