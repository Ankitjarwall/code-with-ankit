import React from 'react'
import Navbar from './navbar'

function Onebook(){
     
        return (
            <div>
                <Navbar />
                <h1>get book info by id</h1>
            </div>
        )
    }


export default Onebook
