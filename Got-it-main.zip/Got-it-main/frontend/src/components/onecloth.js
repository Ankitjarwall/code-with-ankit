import React from 'react'
import Navbar from './navbar'

function Onecloth(){
     
        return (
            <div>
                <Navbar/>
                <h1>get cloth info by id</h1>
            </div>
        )
    }


export default Onecloth
