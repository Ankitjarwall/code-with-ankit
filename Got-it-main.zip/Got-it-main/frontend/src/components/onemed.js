import React from 'react'
import Navbar from './navbar'

function Onemed(){
     
        return (
            <div>
                <Navbar/>
                <h1>get med info by id</h1>
            </div>
        )
    }


export default Onemed
